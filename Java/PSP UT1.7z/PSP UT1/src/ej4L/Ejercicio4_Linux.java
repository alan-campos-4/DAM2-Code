package ej4L;


public class Ejercicio4_Linux
{
	public static void main(String[] args)
	{
		//
	}
}

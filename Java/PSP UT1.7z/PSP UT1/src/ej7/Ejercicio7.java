package ej7;

/* 
 * Este ejercicio es libre, en el demostraréis vuestros conocimientos sobre procesos 
 * y comunicación entre los mismos utilizando un ejemplo libre, diferente para cada uno donde explicaréis 
 * como se arrancan, comunican y paran procesos desde una aplicación java. 
 */

public class Ejercicio7
{
	public static void main(String[] args)
	{
		//
	}
}
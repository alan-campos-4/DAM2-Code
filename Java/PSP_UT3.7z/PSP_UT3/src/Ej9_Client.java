import java.util.Scanner;

public class Ej9_Client
{
	static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args)
	{
		//
	}
	
}


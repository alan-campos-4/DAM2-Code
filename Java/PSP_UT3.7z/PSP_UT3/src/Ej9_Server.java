import java.util.Scanner;

/*


*/

public class Ej9_Server
{
	static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args)
	{
		//
	}
	
}

